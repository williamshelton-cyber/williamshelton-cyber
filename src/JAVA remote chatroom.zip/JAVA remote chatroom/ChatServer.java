                                //这个是服务端的程序！（无GUI版）
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class ChatServer {
private ServerSocket serverSocket;// 存储所有连接到服务器的客户端处理器
private List<ClientHandler> clients = new ArrayList<>();// 存储客户端ID和对应的客户端处理器的映射关系
private Map<String, ClientHandler> idToHandlerMap = new HashMap<>();// 存储所有连接到服务器的客户端处理器
private List<String> chatRecords = new ArrayList<>(); // 存储聊天记录
private Map<String, List<String>> messageReceivers = new HashMap<>();// 存储消息及其接收者

    // 启动服务器，监听指定的端口
    public void start(int port) throws IOException {
    serverSocket = new ServerSocket(port);
        System.out.println("服务器启动，监听端口 " + port);
        while (true) {
            Socket clientSocket = serverSocket.accept();// 等待客户端连接
            System.out.println("新客户端连接：" + clientSocket.getInetAddress());

            // 创建客户端处理器：作用是处理与客户端之间的IO读写操作。
            ClientHandler handler = new ClientHandler(clientSocket, this);
            // 使用同步代码块，确保在多线程环境下安全地修改clients集合
            synchronized (clients) {// 将新创建的客户端处理器添加到集合中，方便后续管理和消息广播
                clients.add(handler);
            }
            // 创建一个新线程来处理该客户端的IO读写操作，并启动线程执行handler的run()方法
            new Thread(handler).start();//这个start()方法会调用handler的run()方法

            if (handler.id != null) {
                idToHandlerMap.put(handler.id, handler);// 将客户端ID和对应的客户端处理器添加到映射关系中，方便后续查找和消息发送
                // 发送历史聊天记录给新连接的客户端
                for (String record : chatRecords) {
                    handler.sendMessage(record);
                }
            }
        }
    }


    // 定义一个方法，用于将消息广播给除发送者以外的所有客户端
    public void broadcast(String message, ClientHandler sender) {
        // 使用同步代码块，确保在多线程环境下遍历和操作clients集合时线程安全
        synchronized (clients) {
            List<String> receivers = new ArrayList<>();
            // 遍历所有已连接的客户端处理器
            for (ClientHandler client : clients) {
                // 如果当前客户端不是消息的发送者，则执行发送
                if (client != sender) {         
     client.sendMessage(message);// 调用客户端处理器的sendMessage方法，将消息写出到客户端
    receivers.add("id: " + client.id + ", name: " + client.name);// 记录接收者信息
                }
            }
             messageReceivers.put(message, receivers); // 存储接收者信息
        }
        chatRecords.add(message); // 存储聊天记录
    }
    
    // 定义一个方法，用于处理查询消息接收者的请求
    public void handleReceiverQuery(ClientHandler sender, String targetMessage) {
        boolean found = false;
        for (Map.Entry<String, List<String>> entry : messageReceivers.entrySet()) {// 遍历存储的消息及其接收者信息
            String storedMessage = entry.getKey();// 遍历存储的消息及其接收者信息
            if (storedMessage.contains(targetMessage)) {
                sender.sendMessage("Receivers of the message containing '" + targetMessage + "':");
                List<String> receivers = entry.getValue();
                for (String receiver : receivers) {
                    sender.sendMessage(receiver);
                }
                found = true; // boolean标记,test if找到匹配的消息
            }
        }
        if (!found) {
            sender.sendMessage("No receivers found for messages containing '" + targetMessage + "'.");
        }
    }


    // 定义一个方法，用于在客户端断开连接后移除其对应的处理器
    public void removeClient(ClientHandler handler) {
        // 使用同步代码块确保在多线程环境下安全地移除客户端处理器
        synchronized (clients) {
            // 从clients集合中移除指定的客户端处理器
            clients.remove(handler);
        }
        if (handler.id != null) {
            idToHandlerMap.remove(handler.id);
        }
    }

    public static void main(String[] args) {
        int port = 1107;  
        ChatServer server = new ChatServer();
        try {
            server.start(port);  // 启动服务器，开始监听客户端连接
        } catch (IOException e) {
            System.out.println("服务器启动失败：");
            e.printStackTrace();
        } 
    }

  // 客户端处理器类，实现Runnable接口 作用是处理与客户端之间的IO读写操作。
// 每个客户端连接到服务器后，服务器都会为其创建一个独立的线程来处理该客户端的IO读写操作。
// 每个线程都有自己的输入流和输出流，用于与客户端进行通信。
class ClientHandler implements Runnable {
    private Socket socket;
    private ChatServer server;                   // 引用服务器，用于消息广播与客户端管理
    private BufferedReader in;
    private PrintWriter out;
    public String id;  // 客户端ID
    public String name; // 客户端用户名

    public ClientHandler(Socket socket, ChatServer server) {// 构造函数，用于初始化客户端处理器的属性
      this.socket = socket;   this.server = server;
        try {
            // 用 InputStreamReader 将字节流转换为字符流，并指定 UTF-8 编码以防中文乱码
            in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
        } catch (IOException e) {
            System.out.println("创建输入输出流时发生异常：");
            e.printStackTrace();
        }
    }

    // 重写 run() 方法，此方法将在独立线程中执行，用于持续监听和处理客户端消息
    @Override
    public void run() {
        try {
            // 读取客户端发送的第一行消息，格式为 "id:xxx name:xxx"
            String initMessage = in.readLine();
            if (initMessage != null) {
                // 解析客户端发送的ID和用户名（这只是发送过来的，不是最后显示出来的！）
                String[] parts = initMessage.split(" ");
                if (parts.length >= 2) {
                    this.id = parts[0].substring(3);  // 去掉 "id:" 前缀
                    this.name = parts[1].substring(5); // 去掉 "name:" 前缀
                }
            }

            // 存储客户端发送的消息
            String message;
            //String message=in.readLine();//这是错误的。如果客户端输入 121 后没有关闭连接，并且后续没有发送新的消息，in.readLine() 会一直阻塞等待新的输入，而不会返回 null。因此，while (message != null) 这个条件会一直成立，导致无限循环。
           
           
            // 循环读取客户端发送的消息，直到客户端断开连接或出现异常
            while ((message= in.readLine()) != null) {
                System.out.println("收到消息：" + message);
//in.readLine() 方法会阻塞等待客户端发送消息，直到客户端发送消息或者客户端断开连接。如果客户端没有发送消息，in.readLine() 方法会一直阻塞，直到客户端发送消息或者客户端断开连接。因此，in.readLine() 方法不会返回 null，而是会一直阻塞等待客户端发送消息。

//while ((message = in.readLine()) != null) 中给 message 赋值后，这个赋值后的 message 变量的值在整个循环体中都是有效的。只要循环没有结束，后续代码就可以使用这个被赋值后的 message 变量。


//服务器端输出的消息包含了 id 和 name 信息，这是因为客户端在发送消息时对消息进行了格式化，添加了 id 和 name 信息
//服务器接收到的就是格式化后的完整消息
                if (message.equals("exit")) {
                    System.out.println("客户端退出：" + socket.getInetAddress());
        try {  socket.close();} catch (IOException e) {e.printStackTrace();}
                    break;
                }

                if (message.startsWith("[print-receiver]:")) {
                    String targetMessage = message.substring(17);
                    server.handleReceiverQuery(this, targetMessage);
                }

                // 关键词检测
                if (message.toUpperCase().contains("BADWORD") || message.toUpperCase().contains("dirtyword")) {
                    System.out.println("检测到不良信息，进行处理...");
                    try {
                        sendMessage("服务器繁忙，请稍后再试！");
//这个sendMessage是ClientHandler类的方法还是ChatServer类的方法还是ChatClient类的方法？答案：是ClientHandler类的方法。
//当在一个类的方法中直接调用一个方法（没有使用对象来显式指定）时，Java 会按照以下顺序查找该方法：
//1.当前类：首先会在当前类中查找是否有匹配的方法。
//2.父类：如果当前类中没有找到匹配的方法，会在当前类的父类中查找是否有匹配的方法。
//3.接口：如果当前类和父类中都没有找到匹配的方法，会在当前类实现的接口中查找是否有匹配的方法。
//4.父类的接口：如果当前类和父类中都没有找到匹配的方法，会在当前类的父类实现的接口中查找是否有匹配的方法。
                        
                          Thread.sleep(5000); // 休眠 5 秒，模拟处理不良信息
        } catch (InterruptedException e) {System.err.println("线程休眠被中断：" + e.getMessage());}
                    continue;
                }

                // 检测是否包含特定关键词
                if (message.toUpperCase().contains("CUHKSZ")) {
                    try {
                        System.out.println("检测到敏感信息，进行处理...");
                        sendMessage("服务器繁忙，请稍后再试！");
                        Thread.sleep(5000); // 休眠 5 秒，模拟处理不良信息
                    } catch (InterruptedException e) {
                        System.err.println("线程休眠被中断：" + e.getMessage());
                    }
                    sendMessage("我们换个话题吧！（香港中文大学（深圳）是中外合作办学的生动实践，我们都要爱护她！）");
                    continue;
                }

                // 广播消息给其他客户端
                server.broadcast(message, this);
            }
        } catch (IOException e) {
            // 读取消息出错时打印错误信息
            System.err.println("读取消息出错：" + e.getMessage());
        } finally {
            // 无论是否发生异常，都在 finally 块中执行资源清理工作
            server.removeClient(this);
            try {// 关闭客户端连接并移除客户端处理器
                socket.close();
                if (id != null && name != null) {
                    String leaveMessage = id + " " + name + " 离开了聊天室";
                    //这个id和name是指客户端的id和name，不是指服务器的id和name。疑问：哪个客户端？答案：当前客户端。为什么？答案：当前客户端是指调用 handleClientDisconnect 方法的 ClientHandler 对象，也就是当前正在处理的客户端。
                    System.out.println(leaveMessage);
                    server.broadcast(leaveMessage, this);// 广播离开消息给其他客户端
                    //这个this是指当前客户端的ClientHandler，不是指服务器的ClientHandler。解释这个语法现象的原因是，在 Java 中，方法的调用是通过对象来完成的。在这个例子中，sendMessage 方法是 ClientHandler 类的一个方法，它的调用是通过 this 关键字来完成的。this 表示当前对象，也就是调用 sendMessage 方法的 ClientHandler 对象。因此，this.sendMessage(message) 就是调用当前对象的 sendMessage 方法，将消息 message 发送给客户端。
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    // 定义 sendMessage 方法，用于向客户端发送消息
    public void sendMessage(String message) {
        out.println(message);  //这里就不要在格式化了，因为客户端已经格式化了。否则会重复！
    }
   
 }
}