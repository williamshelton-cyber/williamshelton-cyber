                            //这个是客户端的程序！（无GUI版）
import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.*;

// 聊天客户端类
public class ChatClient {
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private String id;
    private String name;

    private static Set<String> assignedIds = new HashSet<>();//用于存储已分配的ID，确保ID唯一
    private List<String> chatRecords = new ArrayList<>(); // 存储聊天记录
   

    public void requestReceivers(String message) {
        String request = "[print-receiver]:" + message;
        out.println(request);
    }
   

    // 生成唯一的5位ID
    public static String generateUniqueID() {
        while (true) {  // 循环直到生成唯一的ID
            int id = (int) (Math.random() * 90000) + 10000;
            String idStr = String.valueOf(id);
            if (!assignedIds.contains(idStr)) {  // 如果ID未被分配，则分配并返回
                assignedIds.add(idStr);
                return idStr;
            }
        }
    }

    public ChatClient(String id, String name) {// 构造函数，接收ID和用户名作为参数
        this.id = id;     this.name = name;
    }

    // 连接到服务器的方法
    public void connect(String host, int port) throws IOException {
        socket = new Socket(host, port);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);

        out.println("id:" + id + " name:" + name);// 发送ID和用户名到服务器(但不显示在控制台)
        System.out.println("确认：你的id:" + id + " 你的name:" + name);

        // 启动一个新线程，用于监听服务器发送的消息
        new Thread(() -> {//语法：new Thread(() -> { 线程执行的代码 }).start(); 是一种简化的匿名内部类的写法
            String message;
            try {
                while ((message = in.readLine()) != null) {
                    java.util.Date now = new java.util.Date();
                    java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String time = sdf.format(now);
                    String formattedMessage = "[" + time + "] " + message;
                    System.out.println(formattedMessage);
                    chatRecords.add(formattedMessage); // 存储聊天记录
                }
            } catch (IOException e) {
                System.err.println("连接服务器时发生错误：" + e.getMessage());
            }
        }).start(); //这个start()方法是Thread类的一个方法，用于启动线程的执行；当调用start()方法时，会创建一个新的线程，并在新的线程中执行run()方法中的代码。
    }

    // 写一个向服务器发送消息的方法（这里是格式化消息）
    public void sendMessage(String message) {
        java.util.Date now = new java.util.Date();
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MM-dd HH:mm:ss");
        String time = sdf.format(now);
String formattedMessage = "id：[" + id + "] name：[" + name + "] " + time + ": " + message;
        out.println(formattedMessage);// 发送格式化后的消息到服务器
        chatRecords.add(formattedMessage); // 存储聊天记录
//add 是 List 接口定义的一个方法，用于向列表中添加元素
        // 记录当前消息的接收者信息（这里暂时为空，后续由服务器返回信息填充）
    }
   
    // 搜索聊天记录
    public void searchChatRecords(String keyword) {
        for (String record : chatRecords) {
            if (record.contains(keyword)) {System.out.println("记录："+record);}
        }
    }


    public static void main(String[] args) {
        String str1 = generateUniqueID();
        System.out.println("你的ID是：" + str1 + " 请输入你的用户名：(回车确认)");
        Scanner scanner = new Scanner(System.in);
        String str2 = scanner.nextLine();
        ChatClient client = new ChatClient(str1, str2);// 初始化客户端对象

        try {
            client.connect("localhost", 1107);
            BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
            String line;
            System.out.println("你好，请输入消息，回车发送：");
            while ((line = consoleReader.readLine()) != null) {
                if (line.startsWith("#search ")) { // 搜索功能
                    String keyword = line.substring(8);
                    client.searchChatRecords(keyword);
                }
                else if (line.startsWith("[print-receiver]:")){// print功能
                    String targetMessage = line.substring(17);
                    client.requestReceivers(targetMessage);
                }
                else {
                    client.sendMessage(line);
                }
                System.out.println("你好，请输入消息，回车发送：");
            }
        } catch (IOException e) {
            System.out.println("连接服务器时发生错误：");
            e.printStackTrace();
        }
        scanner.close();
    }
}

//备注：现消息重复的原因是在 ChatClient 的 sendMessage 方法中，格式化消息时包含了 [id][name] 时间:，而在 ClientHandler 的 run 方法中再次进行了相同的格式化，导致消息重复。
//解决方案
//解决消息重复问题：只在一个地方进行消息格式化，这里选择在 ChatClient 进行格式化。
//实现搜索功能：在 ChatClient 中添加搜索功能，通过输入 #search (keyword or username) 来搜索聊天记录

  //tips：用户数据储存在server端更加稳定，安全
