&nbsp;                          Java-ChatRoom Project（outline）

【substract】:

&nbsp; Java Chat Room. 

The basic features include 1) Multithreading Implementation, 2) Chat Room Functions, and 3) Message Display.



The first file is the Server.java, which is responsible for handling client connections and managing the chat room. 



The second file is the Client.java, which is responsible for connecting to the server and sending and receiving messages.



The Server.java file contains the main method, which starts the server and listens for client connections. It also contains a method called handleClient, which is responsible for handling each client connection.

&nbsp;

【注意】：如果真的希望远程提醒记得把自己设备的地址填进去而不是localhost！



推荐测试脚本：

1.启动server和第一个client（我们称为：first），我们给他a.随机分配ID；b.自取名；

2.在first里面输入：hello server！  查看server端：查看显示的：时间，名字，id；

3.再运行第二个多线程用户：second 输入hello server！I'm second!查看first和server端显示的：时间，名字，id；

4.在second 随机输入一串数字和英文组合与see you之后退出再查看；first和server端；

5.创建第三个third 发送hello，查看first和server端

6.测试search命令：

&nbsp;  6.1在first端连续输出good×2，之后再third也回应good\*2，nice\*2，+test时候的time；

&nbsp;  测试#search good命令；#search third等命令

&nbsp;  6.2.在回到first端写入一些文字，进行测试#search third，#search first等命令；

7.测试：\[print-receiver]:命令：

&nbsp;  7.1在first端测试 \[print-receiver]:good命令；

&nbsp;  7.2在third端测试 \[print-receiver]:good命令；

8\.夹带私货：测试输入脏话或敏感词会“服务器繁忙”乃至中断线程。



Date: March 5, 2025（2025.3.5 night）

